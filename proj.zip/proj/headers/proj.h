#ifndef _H_PROJ_
#define _H_PROJ_

#include <lcom/lcf.h>
#include <stdint.h>
#include <stdio.h>
#include "../headers/graphic.h"
#include "../headers/rtc.h"
#include "../headers/Chars.h"
#include "../headers/race.h"
#include "../headers/menus.h"
#include "../headers/sprite.h"
#include "../headers/best_results.h"
#include <machine/int86.h>


#endif
