var searchData=
[
  ['best_5fresults_545',['BEST_RESULTS',['../menus_8h.html#ab20ca178b7ced82aacc9d5a78f3d8321ab2849d9a8e1b44d752edc2158d176783',1,'menus.h']]]
];
