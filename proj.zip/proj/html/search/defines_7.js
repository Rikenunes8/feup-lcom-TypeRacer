var searchData=
[
  ['ibf_615',['IBF',['../i8042_8h.html#a3c48b10907056351582baf9f6478598e',1,'i8042.h']]],
  ['in_5fbuf_616',['IN_BUF',['../i8042_8h.html#a783be5698cf07b1daaf126ef89c19063',1,'i8042.h']]],
  ['irqf_617',['IRQF',['../rtc_8h.html#a8565773f11252b9d615f1b12ac73032d',1,'rtc.h']]]
];
