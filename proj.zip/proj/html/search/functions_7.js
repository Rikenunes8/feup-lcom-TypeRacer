var searchData=
[
  ['kbc_5fih_451',['kbc_ih',['../keyboard_8h.html#aea970a154161a35f6894898a092ed70a',1,'kbc_ih():&#160;keyboard.c'],['../keyboard_8c.html#aea970a154161a35f6894898a092ed70a',1,'kbc_ih():&#160;keyboard.c']]],
  ['kbc_5fwrite_5fbyte_452',['kbc_write_byte',['../mouse_8h.html#a64f61f5254105e5e3229760dc9cf1d9b',1,'kbc_write_byte(uint8_t cmd, uint8_t arg):&#160;mouse.c'],['../mouse_8c.html#a64f61f5254105e5e3229760dc9cf1d9b',1,'kbc_write_byte(uint8_t cmd, uint8_t arg):&#160;mouse.c']]],
  ['kbd_5fsubscribe_5fint_453',['kbd_subscribe_int',['../keyboard_8h.html#a4ac9231a99a664d6a9f0b69767e0d707',1,'kbd_subscribe_int(uint8_t *bit_no):&#160;keyboard.c'],['../keyboard_8c.html#a4ac9231a99a664d6a9f0b69767e0d707',1,'kbd_subscribe_int(uint8_t *bit_no):&#160;keyboard.c']]],
  ['kbd_5funsubscribe_5fint_454',['kbd_unsubscribe_int',['../keyboard_8h.html#aee0a7b54ee426fade9c780418d110fe0',1,'kbd_unsubscribe_int():&#160;keyboard.c'],['../keyboard_8c.html#aee0a7b54ee426fade9c780418d110fe0',1,'kbd_unsubscribe_int():&#160;keyboard.c']]]
];
