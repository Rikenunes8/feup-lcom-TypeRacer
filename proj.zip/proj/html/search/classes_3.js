var searchData=
[
  ['score_356',['Score',['../struct_score.html',1,'']]],
  ['sprite_357',['Sprite',['../struct_sprite.html',1,'']]]
];
