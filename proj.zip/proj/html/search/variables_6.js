var searchData=
[
  ['map_523',['map',['../struct_sprite.html#a0faca9bc52d4868e8b52e44e97862e9f',1,'Sprite::map()'],['../struct_anim_sprite.html#a8038a42524e6270cabfef7cfd039fcd2',1,'AnimSprite::map()']]],
  ['mouse_5fx_524',['mouse_x',['../mouse_8c.html#a1649482b4cd0afe5d8ea4ef86a911b16',1,'mouse.c']]],
  ['mouse_5fy_525',['mouse_y',['../mouse_8c.html#a2da2845d051f38cc5f9850bd65c5aebf',1,'mouse.c']]]
];
