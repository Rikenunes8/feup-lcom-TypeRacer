var searchData=
[
  ['date_517',['date',['../group__best__results.html#ga4fc6f33b46a20c7f37cd620f77132965',1,'Score']]],
  ['dx_518',['dx',['../struct_mouse__event.html#a83d2ce12a8b1a8aa50234aa08fe69343',1,'Mouse_event']]],
  ['dy_519',['dy',['../struct_mouse__event.html#a7882c9cf02bc4ffa6b5d46ab696d51c6',1,'Mouse_event']]]
];
