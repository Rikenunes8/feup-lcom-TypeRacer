var searchData=
[
  ['add_5fscore_392',['add_score',['../group__best__results.html#ga6122d3420e8b6bce76dfa97f615410d2',1,'add_score(size_t CPM, float accuracy, char *name):&#160;best_results.c'],['../group__best__results.html#ga6122d3420e8b6bce76dfa97f615410d2',1,'add_score(size_t CPM, float accuracy, char *name):&#160;best_results.c']]],
  ['animate_5fasprite_393',['animate_asprite',['../group__sprite.html#gaf96910e90e8b6723be7b2418242fd711',1,'animate_asprite(AnimSprite *asp):&#160;sprite.c'],['../group__sprite.html#gaf96910e90e8b6723be7b2418242fd711',1,'animate_asprite(AnimSprite *asp):&#160;sprite.c']]],
  ['animate_5fsprite_394',['animate_sprite',['../group__sprite.html#gae4f7f882c6d2d94aa68d2ff151232354',1,'animate_sprite(Sprite *sprite):&#160;sprite.c'],['../group__sprite.html#gae4f7f882c6d2d94aa68d2ff151232354',1,'animate_sprite(Sprite *sprite):&#160;sprite.c']]],
  ['assemble_5fpacket_395',['assemble_packet',['../mouse_8h.html#a30e8c7c85734629add7c3fa01006a904',1,'assemble_packet(struct packet *pp):&#160;mouse.c'],['../mouse_8c.html#a30e8c7c85734629add7c3fa01006a904',1,'assemble_packet(struct packet *pp):&#160;mouse.c']]],
  ['assemble_5fscancode_396',['assemble_scancode',['../keyboard_8h.html#aad0dda51e288a016d3b9278dfb14436d',1,'assemble_scancode(uint8_t *bytes):&#160;keyboard.c'],['../keyboard_8c.html#aad0dda51e288a016d3b9278dfb14436d',1,'assemble_scancode(uint8_t *bytes):&#160;keyboard.c']]],
  ['aux_5fto_5ffr_5fbuffer_397',['aux_to_fr_buffer',['../graphic_8h.html#a192941c86bbc5df7c8fc3ea68c5a4627',1,'aux_to_fr_buffer(char *aux):&#160;graphic.c'],['../graphic_8c.html#a192941c86bbc5df7c8fc3ea68c5a4627',1,'aux_to_fr_buffer(char *aux):&#160;graphic.c']]]
];
