var searchData=
[
  ['none_562',['none',['../menus_8h.html#a88d8398cd8f09a35d69dea4f2538b6b9ab7e4e0120a041dbe6528b050c04269e0',1,'menus.h']]],
  ['normal_563',['NORMAL',['../_chars_8h.html#a23bb7c444051c8a9161c8a40684bce1ca50d1448013c6f17125caee18aa418af7',1,'Chars.h']]]
];
