var searchData=
[
  ['i8042_2eh_130',['i8042.h',['../i8042_8h.html',1,'']]],
  ['i8254_2eh_131',['i8254.h',['../i8254_8h.html',1,'']]],
  ['ibf_132',['IBF',['../i8042_8h.html#a3c48b10907056351582baf9f6478598e',1,'i8042.h']]],
  ['in_5fbuf_133',['IN_BUF',['../i8042_8h.html#a783be5698cf07b1daaf126ef89c19063',1,'i8042.h']]],
  ['index_134',['index',['../struct_char.html#aae5a12e607d0f782506d9e6ec6179c64',1,'Char']]],
  ['irqf_135',['IRQF',['../rtc_8h.html#a8565773f11252b9d615f1b12ac73032d',1,'rtc.h']]]
];
