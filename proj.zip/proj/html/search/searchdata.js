var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvwxy",
  1: "acms",
  2: "bcgiklmoprstuv",
  3: "abcdfghkmprstuw",
  4: "acdehimnpstwxy",
  5: "cm",
  6: "bcelmnrtw",
  7: "abcdefhiklmnoprstuvwxy",
  8: "bs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros",
  8: "Modules"
};

