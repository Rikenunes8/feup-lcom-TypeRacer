var searchData=
[
  ['print_5fscancode_464',['print_scancode',['../keyboard_8h.html#af067b3348b9675704c05fb6f88eaa811',1,'print_scancode(uint8_t *bytes):&#160;keyboard.c'],['../keyboard_8c.html#af067b3348b9675704c05fb6f88eaa811',1,'print_scancode(uint8_t *bytes):&#160;keyboard.c']]],
  ['proj_5fmain_5floop_465',['proj_main_loop',['../proj_8c.html#a2a16f651eccbd248e1ad3b3b924b143b',1,'proj.c']]]
];
