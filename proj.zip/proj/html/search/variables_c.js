var searchData=
[
  ['x_536',['x',['../struct_sprite.html#af6d3062751bd565decb1a2cd3b63bdb2',1,'Sprite']]],
  ['xspeed_537',['xspeed',['../struct_sprite.html#a999fdb33918588136a72f0488a59e297',1,'Sprite']]]
];
