var searchData=
[
  ['obf_187',['OBF',['../i8042_8h.html#a45967c9e25447ba853cf6fb4ac545fe6',1,'i8042.h']]],
  ['ok_188',['OK',['../vbe_8h.html#aba51915c87d64af47fb1cc59348961c9',1,'vbe.h']]],
  ['others_2eh_189',['others.h',['../others_8h.html',1,'']]],
  ['out_5fbuf_190',['OUT_BUF',['../i8042_8h.html#acfb42dde389e8ca36ab267002fbf5c6a',1,'i8042.h']]]
];
