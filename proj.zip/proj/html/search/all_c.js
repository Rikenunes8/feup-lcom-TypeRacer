var searchData=
[
  ['nack_181',['NACK',['../i8042_8h.html#a958518a45b12053ae33606ee7cb68a55',1,'i8042.h']]],
  ['name_182',['name',['../group__best__results.html#gadb17b9f54ff17e3b134e9614ff8f6742',1,'Score']]],
  ['none_183',['none',['../menus_8h.html#a88d8398cd8f09a35d69dea4f2538b6b9ab7e4e0120a041dbe6528b050c04269e0',1,'menus.h']]],
  ['normal_184',['NORMAL',['../_chars_8h.html#a23bb7c444051c8a9161c8a40684bce1ca50d1448013c6f17125caee18aa418af7',1,'Chars.h']]],
  ['nothing_185',['NOTHING',['../i8042_8h.html#aad4a7ebff687dc5228cc3fd4d25067f2',1,'i8042.h']]],
  ['num_5ffig_186',['num_fig',['../struct_anim_sprite.html#a34e5cc13c19d51c034791e5fc3286592',1,'AnimSprite']]]
];
