var searchData=
[
  ['handle_5falarm_5fint_127',['handle_alarm_int',['../rtc_8h.html#a0c41afc9188c4a687c36b4d37e285012',1,'handle_alarm_int():&#160;rtc.c'],['../rtc_8c.html#a0c41afc9188c4a687c36b4d37e285012',1,'handle_alarm_int():&#160;rtc.c']]],
  ['height_128',['height',['../struct_sprite.html#a81c9f8d0b8c3b49d770be14dbe9f0d37',1,'Sprite']]],
  ['hours_129',['HOURS',['../rtc_8h.html#a212d0f839f6f7ca43ccde311f93d5892',1,'rtc.h']]]
];
