var searchData=
[
  ['name_526',['name',['../group__best__results.html#gadb17b9f54ff17e3b134e9614ff8f6742',1,'Score']]],
  ['num_5ffig_527',['num_fig',['../struct_anim_sprite.html#a34e5cc13c19d51c034791e5fc3286592',1,'AnimSprite']]]
];
