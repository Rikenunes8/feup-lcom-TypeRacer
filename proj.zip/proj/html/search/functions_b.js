var searchData=
[
  ['set_5fasprite_496',['set_asprite',['../group__sprite.html#gaf27f4d37e2ae5aad688af55eb92bc8e2',1,'set_asprite(AnimSprite *asp, uint8_t aspeed, uint8_t cur_aspeed, uint8_t num_fig):&#160;sprite.c'],['../group__sprite.html#gaf27f4d37e2ae5aad688af55eb92bc8e2',1,'set_asprite(AnimSprite *asp, uint8_t aspeed, uint8_t cur_aspeed, uint8_t num_fig):&#160;sprite.c']]],
  ['set_5fasprite_5fsprite_497',['set_asprite_sprite',['../group__sprite.html#ga57936e429a6a692e341728c48ca8db7b',1,'set_asprite_sprite(AnimSprite *asp, uint16_t x, uint16_t y, int32_t x_speed, int32_t y_speed):&#160;sprite.c'],['../group__sprite.html#ga57936e429a6a692e341728c48ca8db7b',1,'set_asprite_sprite(AnimSprite *asp, uint16_t x, uint16_t y, int32_t x_speed, int32_t y_speed):&#160;sprite.c']]],
  ['set_5fresults_498',['set_results',['../race_8h.html#aaabba1591c94f2ff16a7cf879b60a7ae',1,'set_results():&#160;race.c'],['../race_8c.html#aaabba1591c94f2ff16a7cf879b60a7ae',1,'set_results():&#160;race.c']]],
  ['set_5fsprite_499',['set_sprite',['../group__sprite.html#gaa17aa53e85002fceee9ea0fe3c1f856a',1,'set_sprite(Sprite *sprite, uint16_t x, uint16_t y, int32_t x_speed, int32_t y_speed):&#160;sprite.c'],['../group__sprite.html#gaa17aa53e85002fceee9ea0fe3c1f856a',1,'set_sprite(Sprite *sprite, uint16_t x, uint16_t y, int32_t x_speed, int32_t y_speed):&#160;sprite.c']]]
];
