var searchData=
[
  ['packet_5fbyte_5fcounter_528',['packet_byte_counter',['../mouse_8c.html#ac38ffac5d8887c696dcde4d6ed7675a2',1,'mouse.c']]],
  ['posx_529',['posx',['../struct_char.html#ab53192515562274adefccf344085df57',1,'Char']]],
  ['posy_530',['posy',['../struct_char.html#a7d7f37b11271d1c3e7de03e0c570b2d0',1,'Char']]]
];
