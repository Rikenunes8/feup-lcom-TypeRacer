var searchData=
[
  ['wrong_575',['WRONG',['../_chars_8h.html#a23bb7c444051c8a9161c8a40684bce1cae50e47256d3583f0f0cbf9c30c360594',1,'Chars.h']]]
];
