var searchData=
[
  ['x_338',['x',['../struct_sprite.html#af6d3062751bd565decb1a2cd3b63bdb2',1,'Sprite']]],
  ['x_5fbox_339',['X_BOX',['../race_8h.html#af5f39faf52591030c6702ba10e0722dc',1,'race.h']]],
  ['x_5ftext_340',['X_TEXT',['../race_8h.html#aeed6c729663c3b94538e4e1fac0694b6',1,'race.h']]],
  ['x_5ftype_341',['X_TYPE',['../race_8h.html#a1bfca7cd3b69f81a073d1c40cc2f9f8b',1,'race.h']]],
  ['xov_342',['XOV',['../i8042_8h.html#ae1edb2816b16ab2047d8afb9fab347e8',1,'i8042.h']]],
  ['xspeed_343',['xspeed',['../struct_sprite.html#a999fdb33918588136a72f0488a59e297',1,'Sprite']]]
];
