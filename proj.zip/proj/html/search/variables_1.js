var searchData=
[
  ['cpm_514',['cpm',['../group__best__results.html#gae764c6509999d182837c9ac0bf521932',1,'Score']]],
  ['cur_5faspeed_515',['cur_aspeed',['../struct_anim_sprite.html#a60479f0cf93485ff0b888f23886cb39e',1,'AnimSprite']]],
  ['cur_5ffig_516',['cur_fig',['../struct_anim_sprite.html#ab9ca98ed25c375864774f48788db1e39',1,'AnimSprite']]]
];
