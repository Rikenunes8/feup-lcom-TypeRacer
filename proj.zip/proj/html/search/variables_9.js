var searchData=
[
  ['scancode_531',['scancode',['../keyboard_8c.html#abd57ba6a5c3b3e31e8fb3c7d727ffe4b',1,'keyboard.c']]],
  ['sp_532',['sp',['../struct_anim_sprite.html#a02c072c7a9012433f96792739f49fee6',1,'AnimSprite']]],
  ['state_533',['state',['../struct_char.html#a28dcaab9e073a80af3505b4910ef59bb',1,'Char']]]
];
