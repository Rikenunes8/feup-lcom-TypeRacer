var searchData=
[
  ['y_538',['y',['../struct_sprite.html#af64066d134a77e01b3d6eb8da813627a',1,'Sprite']]],
  ['y_5fpos_5ftyped_539',['y_pos_typed',['../race_8h.html#ae7f643b15cd26a007a198592df513bd6',1,'race.h']]],
  ['yspeed_540',['yspeed',['../struct_sprite.html#a69b0badbf75fdefb0711b77b7319b75a',1,'Sprite']]]
];
