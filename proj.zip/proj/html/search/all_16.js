var searchData=
[
  ['y_344',['y',['../struct_sprite.html#af64066d134a77e01b3d6eb8da813627a',1,'Sprite']]],
  ['y_5fbox_345',['Y_BOX',['../race_8h.html#a97e42237fb17a246832af260497a0af4',1,'race.h']]],
  ['y_5fbox_5fmargin_346',['Y_BOX_MARGIN',['../race_8h.html#a4f2c8978af3a75d290689b406d08c282',1,'race.h']]],
  ['y_5fbtw_5fboxes_347',['Y_BTW_BOXES',['../race_8h.html#ae06d7db7e9cf4dac456abc5970582897',1,'race.h']]],
  ['y_5fpos_5ftyped_348',['y_pos_typed',['../race_8h.html#ae7f643b15cd26a007a198592df513bd6',1,'race.h']]],
  ['y_5ftext_349',['Y_TEXT',['../race_8h.html#a926f24a0527fac84047176afde746d4d',1,'race.h']]],
  ['year_350',['YEAR',['../rtc_8h.html#a5871356500f559add06ea81d60331b1b',1,'rtc.h']]],
  ['yov_351',['YOV',['../i8042_8h.html#a77fc5a1075f325b5f67beb9359eb9149',1,'i8042.h']]],
  ['yspeed_352',['yspeed',['../struct_sprite.html#a69b0badbf75fdefb0711b77b7319b75a',1,'Sprite']]]
];
