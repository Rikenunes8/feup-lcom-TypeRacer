var searchData=
[
  ['accuracy_512',['accuracy',['../group__best__results.html#ga4655b4ced08b73119087d8af58680ff1',1,'Score']]],
  ['aspeed_513',['aspeed',['../struct_anim_sprite.html#a98a3a52965ff589977371b54469fa84c',1,'AnimSprite']]]
];
