var searchData=
[
  ['chars_2ec_363',['Chars.c',['../_chars_8c.html',1,'']]],
  ['chars_2eh_364',['Chars.h',['../_chars_8h.html',1,'']]]
];
