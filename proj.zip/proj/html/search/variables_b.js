var searchData=
[
  ['width_535',['width',['../struct_sprite.html#ad0eab1042455a2067c812ab8071d5376',1,'Sprite']]]
];
