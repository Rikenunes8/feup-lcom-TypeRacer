var searchData=
[
  ['char_354',['Char',['../struct_char.html',1,'']]]
];
