var searchData=
[
  ['scancode_262',['scancode',['../keyboard_8c.html#abd57ba6a5c3b3e31e8fb3c7d727ffe4b',1,'keyboard.c']]],
  ['score_263',['Score',['../struct_score.html',1,'']]],
  ['seconds_264',['SECONDS',['../rtc_8h.html#a48fcf4f2eeef6769d588168d4ac2ab0e',1,'rtc.h']]],
  ['set_265',['SET',['../rtc_8h.html#a59da1d65e87a723efe808dbabb4fc205',1,'rtc.h']]],
  ['set_5fasprite_266',['set_asprite',['../group__sprite.html#gaf27f4d37e2ae5aad688af55eb92bc8e2',1,'set_asprite(AnimSprite *asp, uint8_t aspeed, uint8_t cur_aspeed, uint8_t num_fig):&#160;sprite.c'],['../group__sprite.html#gaf27f4d37e2ae5aad688af55eb92bc8e2',1,'set_asprite(AnimSprite *asp, uint8_t aspeed, uint8_t cur_aspeed, uint8_t num_fig):&#160;sprite.c']]],
  ['set_5fasprite_5fsprite_267',['set_asprite_sprite',['../group__sprite.html#ga57936e429a6a692e341728c48ca8db7b',1,'set_asprite_sprite(AnimSprite *asp, uint16_t x, uint16_t y, int32_t x_speed, int32_t y_speed):&#160;sprite.c'],['../group__sprite.html#ga57936e429a6a692e341728c48ca8db7b',1,'set_asprite_sprite(AnimSprite *asp, uint16_t x, uint16_t y, int32_t x_speed, int32_t y_speed):&#160;sprite.c']]],
  ['set_5fresults_268',['set_results',['../race_8h.html#aaabba1591c94f2ff16a7cf879b60a7ae',1,'set_results():&#160;race.c'],['../race_8c.html#aaabba1591c94f2ff16a7cf879b60a7ae',1,'set_results():&#160;race.c']]],
  ['set_5frm_269',['SET_RM',['../i8042_8h.html#adc65ea26d2bc868ff5daba0848eaf39d',1,'i8042.h']]],
  ['set_5fsm_270',['SET_SM',['../i8042_8h.html#a16c54fac24fa591e244b93c5727a8c51',1,'i8042.h']]],
  ['set_5fsprite_271',['set_sprite',['../group__sprite.html#gaa17aa53e85002fceee9ea0fe3c1f856a',1,'set_sprite(Sprite *sprite, uint16_t x, uint16_t y, int32_t x_speed, int32_t y_speed):&#160;sprite.c'],['../group__sprite.html#gaa17aa53e85002fceee9ea0fe3c1f856a',1,'set_sprite(Sprite *sprite, uint16_t x, uint16_t y, int32_t x_speed, int32_t y_speed):&#160;sprite.c']]],
  ['set_5fvbe_5fmode_272',['SET_VBE_MODE',['../vbe_8h.html#ab32156e1d72cb92b120bb16883c87eea',1,'vbe.h']]],
  ['sp_273',['sp',['../struct_anim_sprite.html#a02c072c7a9012433f96792739f49fee6',1,'AnimSprite']]],
  ['space_274',['SPACE',['../i8042_8h.html#a5ff6e798033f03e74730e99f01936f84',1,'i8042.h']]],
  ['speaker_5fctrl_275',['SPEAKER_CTRL',['../i8254_8h.html#a51b3a5e3d4811ca063fe25e35560ab40',1,'i8254.h']]],
  ['sprite_276',['Sprite',['../struct_sprite.html',1,'Sprite'],['../group__sprite.html',1,'(Global Namespace)']]],
  ['sprite_2ec_277',['sprite.c',['../sprite_8c.html',1,'']]],
  ['sprite_2eh_278',['sprite.h',['../sprite_8h.html',1,'']]],
  ['stat_5freg_279',['STAT_REG',['../i8042_8h.html#a89c4d098b53809674457b1660b1af780',1,'i8042.h']]],
  ['state_280',['state',['../struct_char.html#a28dcaab9e073a80af3505b4910ef59bb',1,'Char']]]
];
