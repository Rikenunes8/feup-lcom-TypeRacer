var searchData=
[
  ['fr_5fbuffer_5fto_5faux_432',['fr_buffer_to_aux',['../graphic_8h.html#a6ff36b6bcb3b357b3c259545704d1e60',1,'fr_buffer_to_aux(char *aux):&#160;graphic.c'],['../graphic_8c.html#a6ff36b6bcb3b357b3c259545704d1e60',1,'fr_buffer_to_aux(char *aux):&#160;graphic.c']]],
  ['fr_5fbuffer_5fto_5fvideo_5fmem_433',['fr_buffer_to_video_mem',['../graphic_8h.html#a6eb5c5032c07dd869c2fc31148797725',1,'fr_buffer_to_video_mem():&#160;graphic.c'],['../graphic_8c.html#a6eb5c5032c07dd869c2fc31148797725',1,'fr_buffer_to_video_mem():&#160;graphic.c']]]
];
